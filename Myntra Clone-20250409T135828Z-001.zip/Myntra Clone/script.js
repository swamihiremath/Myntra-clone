let cart = JSON.parse(localStorage.getItem("cart")) || []; // Load existing cart or initialize empty

function add(val) {
    let name, price, description, img;

    if (val == '1') {
        name = document.getElementById("name1").dataset.value;
        price = parseInt(document.getElementById("price1").dataset.value);
        description = document.getElementById("description1").dataset.value;
        img = document.getElementById("pic1").src;

        document.getElementById('but1').style.background = "rgb(83, 87, 102)";
        document.getElementById('but1').style.color = "white";
        document.getElementById('but1').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but1State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '2') {
        name = document.getElementById("name2").dataset.value;
        price = parseInt(document.getElementById("price2").dataset.value);
        description = document.getElementById("description2").dataset.value;
        img = document.getElementById("pic2").src;

        document.getElementById('but2').style.background = "rgb(83, 87, 102)";
        document.getElementById('but2').style.color = "white";
        document.getElementById('but2').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but2State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '3') {
        name = document.getElementById("name3").dataset.value;
        price = parseInt(document.getElementById("price3").dataset.value);
        description = document.getElementById("description3").dataset.value;
        img = document.getElementById("pic3").src;

        document.getElementById('but3').style.background = "rgb(83, 87, 102)";
        document.getElementById('but3').style.color = "white";
        document.getElementById('but3').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but3State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '4') {
        name = document.getElementById("name4").dataset.value;
        price = parseInt(document.getElementById("price4").dataset.value);
        description = document.getElementById("description4").dataset.value;
        img = document.getElementById("pic4").src;

        document.getElementById('but4').style.background = "rgb(83, 87, 102)";
        document.getElementById('but4').style.color = "white";
        document.getElementById('but4').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but4State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '5') {
        name = document.getElementById("name3").dataset.value;
        price = parseInt(document.getElementById("price5").dataset.value);
        description = document.getElementById("description5").dataset.value;
        img = document.getElementById("pic5").src;

        document.getElementById('but5').style.background = "rgb(83, 87, 102)";
        document.getElementById('but5').style.color = "white";
        document.getElementById('but5').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but5State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '6') {
        name = document.getElementById("name6").dataset.value;
        price = parseInt(document.getElementById("price6").dataset.value);
        description = document.getElementById("description6").dataset.value;
        img = document.getElementById("pic6").src;

        document.getElementById('but6').style.background = "rgb(83, 87, 102)";
        document.getElementById('but6').style.color = "white";
        document.getElementById('but6').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but6State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '7') {
        name = document.getElementById("name7").dataset.value;
        price = parseInt(document.getElementById("price7").dataset.value);
        description = document.getElementById("description7").dataset.value;
        img = document.getElementById("pic7").src;

        document.getElementById('but7').style.background = "rgb(83, 87, 102)";
        document.getElementById('but7').style.color = "white";
        document.getElementById('but7').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but7State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '8') {
        name = document.getElementById("name8").dataset.value;
        price = parseInt(document.getElementById("price8").dataset.value);
        description = document.getElementById("description8").dataset.value;
        img = document.getElementById("pic8").src;

        document.getElementById('but8').style.background = "rgb(83, 87, 102)";
        document.getElementById('but8').style.color = "white";
        document.getElementById('but8').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but8State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '9') {
        name = document.getElementById("name9").dataset.value;
        price = parseInt(document.getElementById("price9").dataset.value);
        description = document.getElementById("description9").dataset.value;
        img = document.getElementById("pic9").src;

        document.getElementById('but9').style.background = "rgb(83, 87, 102)";
        document.getElementById('but9').style.color = "white";
        document.getElementById('but9').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but9State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '10') {
        name = document.getElementById("name10").dataset.value;
        price = parseInt(document.getElementById("price10").dataset.value);
        description = document.getElementById("description10").dataset.value;
        img = document.getElementById("pic10").src;

        document.getElementById('but10').style.background = "rgb(83, 87, 102)";
        document.getElementById('but10').style.color = "white";
        document.getElementById('but10').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but10State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '11') {
        name = document.getElementById("name11").dataset.value;
        price = parseInt(document.getElementById("price11").dataset.value);
        description = document.getElementById("description11").dataset.value;
        img = document.getElementById("pic11").src;

        document.getElementById('but11').style.background = "rgb(83, 87, 102)";
        document.getElementById('but11').style.color = "white";
        document.getElementById('but11').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but11State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '12') {
        name = document.getElementById("name12").dataset.value;
        price = parseInt(document.getElementById("price12").dataset.value);
        description = document.getElementById("description12").dataset.value;
        img = document.getElementById("pic12").src;

        document.getElementById('but12').style.background = "rgb(83, 87, 102)";
        document.getElementById('but12').style.color = "white";
        document.getElementById('but12').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but12State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '13') {
        name = document.getElementById("name13").dataset.value;
        price = parseInt(document.getElementById("price13").dataset.value);
        description = document.getElementById("description13").dataset.value;
        img = document.getElementById("pic13").src;

        document.getElementById('but13').style.background = "rgb(83, 87, 102)";
        document.getElementById('but13').style.color = "white";
        document.getElementById('but13').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but13State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '14') {
        name = document.getElementById("name14").dataset.value;
        price = parseInt(document.getElementById("price14").dataset.value);
        description = document.getElementById("description14").dataset.value;
        img = document.getElementById("pic14").src;

        document.getElementById('but14').style.background = "rgb(83, 87, 102)";
        document.getElementById('but14').style.color = "white";
        document.getElementById('but14').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but14State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '15') {
        name = document.getElementById("name15").dataset.value;
        price = parseInt(document.getElementById("price15").dataset.value);
        description = document.getElementById("description15").dataset.value;
        img = document.getElementById("pic15").src;

        document.getElementById('but15').style.background = "rgb(83, 87, 102)";
        document.getElementById('but15').style.color = "white";
        document.getElementById('but15').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but15State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '16') {
        name = document.getElementById("name16").dataset.value;
        price = parseInt(document.getElementById("price16").dataset.value);
        description = document.getElementById("description16").dataset.value;
        img = document.getElementById("pic16").src;

        document.getElementById('but16').style.background = "rgb(83, 87, 102)";
        document.getElementById('but16').style.color = "white";
        document.getElementById('but16').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but16State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '17') {
        name = document.getElementById("name17").dataset.value;
        price = parseInt(document.getElementById("price17").dataset.value);
        description = document.getElementById("description17").dataset.value;
        img = document.getElementById("pic17").src;

        document.getElementById('but17').style.background = "rgb(83, 87, 102)";
        document.getElementById('but17').style.color = "white";
        document.getElementById('but17').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but17State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '18') {
        name = document.getElementById("name18").dataset.value;
        price = parseInt(document.getElementById("price18").dataset.value);
        description = document.getElementById("description18").dataset.value;
        img = document.getElementById("pic18").src;

        document.getElementById('but18').style.background = "rgb(83, 87, 102)";
        document.getElementById('but18').style.color = "white";
        document.getElementById('but18').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but18State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '19') {
        name = document.getElementById("name19").dataset.value;
        price = parseInt(document.getElementById("price19").dataset.value);
        description = document.getElementById("description19").dataset.value;
        img = document.getElementById("pic19").src;

        document.getElementById('but19').style.background = "rgb(83, 87, 102)";
        document.getElementById('but19').style.color = "white";
        document.getElementById('but19').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but19State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '20') {
        name = document.getElementById("name20").dataset.value;
        price = parseInt(document.getElementById("price20").dataset.value);
        description = document.getElementById("description20").dataset.value;
        img = document.getElementById("pic20").src;

        document.getElementById('but20').style.background = "rgb(83, 87, 102)";
        document.getElementById('but20').style.color = "white";
        document.getElementById('but20').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but20State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '21') {
        name = document.getElementById("name21").dataset.value;
        price = parseInt(document.getElementById("price21").dataset.value);
        description = document.getElementById("description21").dataset.value;
        img = document.getElementById("pic21").src;

        document.getElementById('but21').style.background = "rgb(83, 87, 102)";
        document.getElementById('but21').style.color = "white";
        document.getElementById('but21').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but21State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '22') {
        name = document.getElementById("name22").dataset.value;
        price = parseInt(document.getElementById("price22").dataset.value);
        description = document.getElementById("description22").dataset.value;
        img = document.getElementById("pic22").src;

        document.getElementById('but22').style.background = "rgb(83, 87, 102)";
        document.getElementById('but22').style.color = "white";
        document.getElementById('but22').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but22State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '23') {
        name = document.getElementById("name23").dataset.value;
        price = parseInt(document.getElementById("price23").dataset.value);
        description = document.getElementById("description23").dataset.value;
        img = document.getElementById("pic23").src;

        document.getElementById('but23').style.background = "rgb(83, 87, 102)";
        document.getElementById('but23').style.color = "white";
        document.getElementById('but23').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but23State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '24') {
        name = document.getElementById("name24").dataset.value;
        price = parseInt(document.getElementById("price24").dataset.value);
        description = document.getElementById("description24").dataset.value;
        img = document.getElementById("pic24").src;

        document.getElementById('but24').style.background = "rgb(83, 87, 102)";
        document.getElementById('but24').style.color = "white";
        document.getElementById('but24').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but24State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '25') {
        name = document.getElementById("name25").dataset.value;
        price = parseInt(document.getElementById("price25").dataset.value);
        description = document.getElementById("description25").dataset.value;
        img = document.getElementById("pic25").src;

        document.getElementById('but25').style.background = "rgb(83, 87, 102)";
        document.getElementById('but25').style.color = "white";
        document.getElementById('but25').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but25State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '26') {
        name = document.getElementById("name26").dataset.value;
        price = parseInt(document.getElementById("price26").dataset.value);
        description = document.getElementById("description26").dataset.value;
        img = document.getElementById("pic26").src;

        document.getElementById('but26').style.background = "rgb(83, 87, 102)";
        document.getElementById('but26').style.color = "white";
        document.getElementById('but26').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but26State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '27') {
        name = document.getElementById("name27").dataset.value;
        price = parseInt(document.getElementById("price27").dataset.value);
        description = document.getElementById("description27").dataset.value;
        img = document.getElementById("pic27").src;

        document.getElementById('but27').style.background = "rgb(83, 87, 102)";
        document.getElementById('but27').style.color = "white";
        document.getElementById('but27').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but27State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '28') {
        name = document.getElementById("name28").dataset.value;
        price = parseInt(document.getElementById("price28").dataset.value);
        description = document.getElementById("description28").dataset.value;
        img = document.getElementById("pic28").src;

        document.getElementById('but28').style.background = "rgb(83, 87, 102)";
        document.getElementById('but28').style.color = "white";
        document.getElementById('but28').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but28State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    } else if (val == '29') {
        name = document.getElementById("name29").dataset.value;
        price = parseInt(document.getElementById("price29").dataset.value);
        description = document.getElementById("description29").dataset.value;
        img = document.getElementById("pic29").src;

        document.getElementById('but29').style.background = "rgb(83, 87, 102)";
        document.getElementById('but29').style.color = "white";
        document.getElementById('but29').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but29State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    }else if (val == '30') {
        name = document.getElementById("name30").dataset.value;
        price = parseInt(document.getElementById("price30").dataset.value);
        description = document.getElementById("description30").dataset.value;
        img = document.getElementById("pic30").src;

        document.getElementById('but30').style.background = "rgb(83, 87, 102)";
        document.getElementById('but30').style.color = "white";
        document.getElementById('but30').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but30State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    }else if (val == '31') {
        name = document.getElementById("name31").dataset.value;
        price = parseInt(document.getElementById("price31").dataset.value);
        description = document.getElementById("description31").dataset.value;
        img = document.getElementById("pic31").src;

        document.getElementById('but31').style.background = "rgb(83, 87, 102)";
        document.getElementById('but31').style.color = "white";
        document.getElementById('but31').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but31State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    }else if (val == '32') {
        name = document.getElementById("name32").dataset.value;
        price = parseInt(document.getElementById("price32").dataset.value);
        description = document.getElementById("description32").dataset.value;
        img = document.getElementById("pic32").src;

        document.getElementById('but32').style.background = "rgb(83, 87, 102)";
        document.getElementById('but32').style.color = "white";
        document.getElementById('but32').innerHTML = "ITEM ADDED TO BAG";

        localStorage.setItem('but32State', JSON.stringify({
            background: "rgb(83, 87, 102)",
            color: "white",
            text: "ITEM ADDED TO BAG"
        }));

    }



    // Add product to cart array
    cart.push({
        name,
        price,
        description,
        img
    });

    // Save cart to localStorage
    localStorage.setItem("cart", JSON.stringify(cart));

    // Update cart count and total price
    const count = cart.length;
    const rate = cart.reduce((total, item) => total + item.price, 0);

    console.log(`Cart count: ${count}, Total rate: ${rate}`);
}








document.addEventListener("DOMContentLoaded", () => {
    const but1State = JSON.parse(localStorage.getItem('but1State'));

    if (but1State) {
        const button = document.getElementById('but1');
        button.style.background = but1State.background;
        button.style.color = but1State.color;
        button.innerHTML = but1State.text;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const but2State = JSON.parse(localStorage.getItem('but2State'));

    if (but2State) {
        const button = document.getElementById('but2');
        button.style.background = but2State.background;
        button.style.color = but2State.color;
        button.innerHTML = but2State.text;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const but3State = JSON.parse(localStorage.getItem('but3State'));

    if (but3State) {
        const button = document.getElementById('but3');
        button.style.background = but3State.background;
        button.style.color = but3State.color;
        button.innerHTML = but3State.text;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const but4State = JSON.parse(localStorage.getItem('but4State'));

    if (but4State) {
        const button = document.getElementById('but4');
        button.style.background = but4State.background;
        button.style.color = but4State.color;
        button.innerHTML = but4State.text;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const but5State = JSON.parse(localStorage.getItem('but5State'));

    if (but5State) {
        const button = document.getElementById('but5');
        button.style.background = but5State.background;
        button.style.color = but5State.color;
        button.innerHTML = but5State.text;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const but6State = JSON.parse(localStorage.getItem('but6State'));

    if (but6State) {
        const button = document.getElementById('but6');
        button.style.background = but6State.background;
        button.style.color = but6State.color;
        button.innerHTML = but6State.text;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const but7State = JSON.parse(localStorage.getItem('but7State'));

    if (but7State) {
        const button = document.getElementById('but7');
        button.style.background = but7State.background;
        button.style.color = but7State.color;
        button.innerHTML = but7State.text;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const but8State = JSON.parse(localStorage.getItem('but8State'));

    if (but8State) {
        const button = document.getElementById('but8');
        button.style.background = but8State.background;
        button.style.color = but8State.color;
        button.innerHTML = but8State.text;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const but9State = JSON.parse(localStorage.getItem('but9State'));

    if (but9State) {
        const button = document.getElementById('but9');
        button.style.background = but9State.background;
        button.style.color = but9State.color;
        button.innerHTML = but9State.text;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const but10State = JSON.parse(localStorage.getItem('but10State'));

    if (but10State) {
        const button = document.getElementById('but10');
        button.style.background = but10State.background;
        button.style.color = but10State.color;
        button.innerHTML = but10State.text;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const but11State = JSON.parse(localStorage.getItem('but11State'));

    if (but11State) {
        const button = document.getElementById('but11');
        button.style.background = but11State.background;
        button.style.color = but11State.color;
        button.innerHTML = but11State.text;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const but12State = JSON.parse(localStorage.getItem('but12State'));

    if (but12State) {
        const button = document.getElementById('but12');
        button.style.background = but12State.background;
        button.style.color = but12State.color;
        button.innerHTML = but12State.text;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const but13State = JSON.parse(localStorage.getItem('but13State'));

    if (but13State) {
        const button = document.getElementById('but13');
        button.style.background = but13State.background;
        button.style.color = but13State.color;
        button.innerHTML = but13State.text;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const but14State = JSON.parse(localStorage.getItem('but14State'));

    if (but14State) {
        const button = document.getElementById('but14');
        button.style.background = but14State.background;
        button.style.color = but14State.color;
        button.innerHTML = but14State.text;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const but15State = JSON.parse(localStorage.getItem('but15State'));

    if (but15State) {
        const button = document.getElementById('but15');
        button.style.background = but15State.background;
        button.style.color = but15State.color;
        button.innerHTML = but15State.text;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const but16State = JSON.parse(localStorage.getItem('but16State'));

    if (but16State) {
        const button = document.getElementById('but16');
        button.style.background = but16State.background;
        button.style.color = but16State.color;
        button.innerHTML = but16State.text;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const but17State = JSON.parse(localStorage.getItem('but17State'));

    if (but17State) {
        const button = document.getElementById('but17');
        button.style.background = but17State.background;
        button.style.color = but17State.color;
        button.innerHTML = but17State.text;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const but18State = JSON.parse(localStorage.getItem('but18State'));

    if (but18State) {
        const button = document.getElementById('but18');
        button.style.background = but18State.background;
        button.style.color = but18State.color;
        button.innerHTML = but18State.text;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const but19State = JSON.parse(localStorage.getItem('but19State'));

    if (but19State) {
        const button = document.getElementById('but19');
        button.style.background = but19State.background;
        button.style.color = but19State.color;
        button.innerHTML = but19State.text;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const but20State = JSON.parse(localStorage.getItem('but20State'));

    if (but20State) {
        const button = document.getElementById('but20');
        button.style.background = but20State.background;
        button.style.color = but20State.color;
        button.innerHTML = but20State.text;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const but21State = JSON.parse(localStorage.getItem('but21State'));

    if (but21State) {
        const button = document.getElementById('but21');
        button.style.background = but21State.background;
        button.style.color = but21State.color;
        button.innerHTML = but21State.text;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const but22State = JSON.parse(localStorage.getItem('but22State'));

    if (but22State) {
        const button = document.getElementById('but22');
        button.style.background = but22State.background;
        button.style.color = but22State.color;
        button.innerHTML = but22State.text;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const but23State = JSON.parse(localStorage.getItem('but23State'));

    if (but23State) {
        const button = document.getElementById('but23');
        button.style.background = but23State.background;
        button.style.color = but23State.color;
        button.innerHTML = but23State.text;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const but24State = JSON.parse(localStorage.getItem('but24State'));

    if (but24State) {
        const button = document.getElementById('but24');
        button.style.background = but24State.background;
        button.style.color = but24State.color;
        button.innerHTML = but24State.text;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const but25State = JSON.parse(localStorage.getItem('but25State'));

    if (but25State) {
        const button = document.getElementById('but25');
        button.style.background = but25State.background;
        button.style.color = but25State.color;
        button.innerHTML = but25State.text;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const but26State = JSON.parse(localStorage.getItem('but26State'));

    if (but26State) {
        const button = document.getElementById('but26');
        button.style.background = but26State.background;
        button.style.color = but26State.color;
        button.innerHTML = but26State.text;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const but27State = JSON.parse(localStorage.getItem('but27State'));

    if (but27State) {
        const button = document.getElementById('but27');
        button.style.background = but27State.background;
        button.style.color = but27State.color;
        button.innerHTML = but27State.text;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const but28State = JSON.parse(localStorage.getItem('but28State'));

    if (but28State) {
        const button = document.getElementById('but28');
        button.style.background = but28State.background;
        button.style.color = but28State.color;
        button.innerHTML = but28State.text;
    }
})

document.addEventListener("DOMContentLoaded", () => {
    const but29State = JSON.parse(localStorage.getItem('but29State'));

    if (but29State) {
        const button = document.getElementById('but29');
        button.style.background = but29State.background;
        button.style.color = but29State.color;
        button.innerHTML = but29State.text;
    }
})

document.addEventListener("DOMContentLoaded", () => {
    const but30State = JSON.parse(localStorage.getItem('but30State'));

    if (but30State) {
        const button = document.getElementById('but30');
        button.style.background = but30State.background;
        button.style.color = but30State.color;
        button.innerHTML = but30State.text;
    }
})

document.addEventListener("DOMContentLoaded", () => {
    const but31State = JSON.parse(localStorage.getItem('but31State'));

    if (but31State) {
        const button = document.getElementById('but31');
        button.style.background = but31State.background;
        button.style.color = but31State.color;
        button.innerHTML = but31State.text;
    }
})

document.addEventListener("DOMContentLoaded", () => {
    const but32State = JSON.parse(localStorage.getItem('but32State'));

    if (but32State) {
        const button = document.getElementById('but32');
        button.style.background = but32State.background;
        button.style.color = but32State.color;
        button.innerHTML = but32State.text;
    }
})

document.addEventListener("DOMContentLoaded", function () {
    const navbar = document.querySelector(".nav-dim");
    const overlay = document.querySelector(".overlay");

    navbar.addEventListener("mouseenter", function () {
        document.body.classList.add("dim");
    });

    navbar.addEventListener("mouseleave", function () {
        document.body.classList.remove("dim");
    });
});
    
// In the above code, we first select the navbar and overlay elements using the querySelector method. We then add an event listener to the navbar element for the mouseenter event. When the mouse enters the navbar, we add the dim class to the body







if (performance.navigation.type === 1) {
    localStorage.clear();
}